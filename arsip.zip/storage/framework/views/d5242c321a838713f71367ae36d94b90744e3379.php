<table class="table table-sm" width="100%">
    <tbody class="bg-secondary">
        <tr>
            <th class="sticky-top th-atas">No Berkas</th>
            <th class="sticky-top th-atas">Kecamatan</th>
            <th class="sticky-top th-atas">Kelurahan</th>
            <th class="sticky-top th-atas">Pelayanan</th>            
            <th class="sticky-top th-atas">Tipe Hak</th>
            <th class="sticky-top th-atas">No Hak</th>
            <th class="sticky-top th-atas">Jenis Arsip</th>
            <th class="sticky-top th-atas">Keterangan</th>
          </tr>
    </tbody>
<?php $__currentLoopData = $pengajuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tbody data-toggle="collapse" data-target="#<?php echo e($d->no_tiket); ?>" class=" <?php echo e($d->urgent == 1 ? 'blink' : 'bg-info'); ?> clickable thead_pengajuan" aria-expanded="true">
        <tr>
            <th colspan="2"><?php echo e($d->seksi->nm_seksi); ?> (<?php echo e($d->user->name); ?>)</th>
            <th colspan="2"><?php echo e(date("d-M-Y H:i", strtotime($d->created_at))); ?></th>
            <th><?php echo e($d->selisih); ?> Hari</th>
            <th>
                <?php if(Auth::user()->seksi_id == 1): ?>
                <div class="custom-control custom-switch custom-switch-off-light custom-switch-on-warning">
                    <input type="checkbox" class="custom-control-input checkbox_urgent" name="urgent" id="urgent<?php echo e($d->no_tiket); ?>" value="<?php echo e($d->no_tiket); ?>" <?php echo e($d->urgent == 1 ? 'checked' : ''); ?>>
                    <label class="custom-control-label" for="urgent<?php echo e($d->no_tiket); ?>">Urgent</label>
                </div>
                <?php endif; ?>
                
            </th>
            <th>No Tiket : <?php echo e($d->no_tiket); ?>

                <?php
                        $nohak = '';
                    ?>
                <?php $__currentLoopData = $d->peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $nohak .= ' '.$p->no_hak. ' '. $p->kecamatan->nm_kecamatan. ' '. $p->kelurahan->nm_kelurahan. ' '. $p->pelayanan->nm_pelayanan. ' '. $p->hak->nm_hak. ' '. $p->jenis_arsip. ' '. $p->keterangan. ' '. $p->no_berkas. ' '. $d->seksi->nm_seksi.' '.$d->user->name. ' '.date("d-M-Y H:i", strtotime($d->created_at));
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <small style="font-size: 0.1px;">&nbsp; <?php echo e($nohak); ?></small>
            </th>
            <th>
                <?php if(Auth::user()->seksi_id == 1 || Auth::user()->seksi_id == 4): ?>
                <a href="<?php echo e(route('inputPengajuan',['tiket' => $d->no_tiket])); ?>" class="btn btn-xs btn-secondary"><i class="fas fa-edit"></i></a> 
                <a class="btn btn-xs btn-secondary" target="_blank" href="<?php echo e(route('printPengajuan',['tiket' => $d->no_tiket])); ?>"><i class="fas fa-print"></i> Print</a>
                <?php endif; ?>
                
            </th>
        </tr>
    </tbody>
    <tbody id="<?php echo e($d->no_tiket); ?>" class="collapse show text-center tbody_pengajuan">
        <?php $__currentLoopData = $d->peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($p->no_berkas); ?></td>
                <td><?php echo e($p->kecamatan->nm_kecamatan); ?></td>
                <td><?php echo e($p->kelurahan->nm_kelurahan); ?></td>
                <td><?php echo e($p->pelayanan->nm_pelayanan); ?></td>                
                <td><?php echo e($p->hak->nm_hak); ?></td>
                <td><?php echo e($p->no_hak); ?></td>
                <td><?php echo e($p->jenis_arsip); ?></td>
                <td><?php echo e($p->keterangan); ?> <small style="font-size: 0.1px;"><?php echo e($nohak); ?></small></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
    </tbody>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
  </table><?php /**PATH D:\programming\Laravel\arsip\resources\views/page/pengajuan.blade.php ENDPATH**/ ?>