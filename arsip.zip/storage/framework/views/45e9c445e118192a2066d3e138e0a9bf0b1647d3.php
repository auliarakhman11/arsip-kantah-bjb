<?php if($pengajuan): ?>
<div class="container-fluid">    
    <table class="table table-sm">
        <thead class="text-center">
            <tr>
                <th>#</th>
                <th>Kecamatan</th>
                <th>Kelurahan</th>
                <th>No Berkas</th>
                <th>Tipe Hak</th>
                <th>No Hak</th>
                <th>Jenis</th>
                <th>Pelayanan</th>
                <th>Keterangan</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody class="text-center">
            <?php $i=1; ?>
            <?php $__currentLoopData = $pengajuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($p->kecamatan->nm_kecamatan); ?></td>
                    <td><?php echo e($p->kelurahan->nm_kelurahan); ?></td>
                    <td><?php echo e($p->no_berkas); ?></td>
                    <td><?php echo e($p->hak->nm_hak); ?></td>
                    <td><?php echo e($p->no_hak); ?></td>
                    <td><?php echo e($p->jenis_arsip); ?></td>
                    <td><?php echo e($p->pelayanan->nm_pelayanan); ?></td>
                    <td><?php echo e($p->keterangan); ?></td>
                    <td>
                        <?php if($p->jenis_history == 'kirim'): ?>
                            <a href="#modal_terima_kirim" class="btn btn-xs btn-success terima_kirim" data-toggle="modal" id_peminjaman="<?php echo e($p->id); ?>"><i class="fas fa-check-square"></i> Arsip dikirim</a>
                        <?php else: ?>
                        Pengajuan
                        <?php endif; ?>
                        
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php else: ?>
<h4>Belum ada pengajuan</h4>
<?php endif; ?>

<?php /**PATH /media/rahman/DATA D1/Programming/laravel/arsip/resources/views/peminjaman/pengajuan.blade.php ENDPATH**/ ?>