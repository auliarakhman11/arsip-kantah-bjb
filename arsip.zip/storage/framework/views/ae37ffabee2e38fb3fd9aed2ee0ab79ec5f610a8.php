<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print Semua</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>

<div class="container-fluid">
<div class="row">
    <div class="col-12">
    <table class="table table-bordered">
        <thead class="thead-light">
            <tr>
                <th>No Berkas</th>
                <th>Kecamatan</th>
                <th>Kelurahan</th>
                <th>Pelayanan</th> 
                <th>Tipe Hak</th>
                <th>No Hak</th>
                <th>Jenis Arsip</th>                                       
                <th>Keterangan</th>
                <th>Seksi/User</th>
                <th>#</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pengajuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($p->no_berkas); ?></td> 
                <td><?php echo e($p->kecamatan->nm_kecamatan); ?></td>
                <td><?php echo e($p->kelurahan->nm_kelurahan); ?></td>
                <td><?php echo e($p->pelayanan->nm_pelayanan); ?></td>
                <td><?php echo e($p->hak->nm_hak); ?></td>
                <td><?php echo e($p->no_hak); ?></td>
                <td><?php echo e($p->jenis_arsip); ?></td>                                            
                <td><?php echo e($p->keterangan); ?></td>
                <td><?php echo e($p->seksi->nm_seksi); ?> (<?php echo e($p->user->name); ?>)</td>
                <td></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    
    </div>
</div>
</div>
    

</body>
</html><?php /**PATH /home/u1721841/arsip/resources/views/page/print_all_pengajuan.blade.php ENDPATH**/ ?>