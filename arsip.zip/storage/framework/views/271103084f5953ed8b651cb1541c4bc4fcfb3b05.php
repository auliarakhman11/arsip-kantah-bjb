  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="" class="brand-link">
      <img src="<?php echo e(asset('img')); ?>/Logo_BPN-KemenATR.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-light">ATR-BPN</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      

      <!-- SidebarSearch Form -->
      

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          

          <li class="nav-item <?php echo e(Request::is(['/','peminjaman','pengembalian']) ? 'menu-open' : ''); ?>">
            <a href="#" class="nav-link <?php echo e(Request::is(['/','peminjaman','pengembalian']) ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-list-ul"></i>
              <p>
                Peminjaman
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">

              <li class="nav-item">
                <a href="<?php echo e(route('home')); ?>" class="nav-link <?php echo e(Request::is('/') ? 'active' : ''); ?>">
                  <i class="fas fa-minus nav-icon"></i>
                  <p>List Peminjaman</p>
                </a>
              </li>
              <?php if(Auth::user()->seksi_id !=4): ?>
                <li class="nav-item">
                  <a href="<?php echo e(route('peminjaman')); ?>" class="nav-link <?php echo e(Request::is('peminjaman') ? 'active' : ''); ?>">
                    <i class="fas fa-minus nav-icon"></i>
                    <p>Peminjaman</p>
                  </a>
                </li>

                <li class="nav-item">
                  <a href="<?php echo e(route('pengembalian')); ?>" class="nav-link <?php echo e(Request::is('pengembalian') ? 'active' : ''); ?>">
                    <i class="fas fa-minus nav-icon"></i>
                    <p>Pengembalian</p>
                  </a>
                </li>
              <?php endif; ?>
              

              
            </ul>
          </li>

          <?php if(Auth::user()->seksi_id !=4): ?>
          <li class="nav-item <?php echo e(Request::is(['st','ba','ba-pps']) ? 'menu-open' : ''); ?>">
            <a href="#" class="nav-link <?php echo e(Request::is(['st','ba','ba-pps']) ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-envelope-open-text"></i>
              <p>
                <span style="font-size: 14px">Surat Tugas & Berita acara</span>
              </p>
              <p><i class="right fas fa-angle-left"></i></p>
            </a>
            <ul class="nav nav-treeview">

              <li class="nav-item">
                <a href="<?php echo e(route('St')); ?>" class="nav-link <?php echo e(Request::is('st') ? 'active' : ''); ?>">
                  <i class="fas fa-minus nav-icon"></i>
                  <p>Surat Tugas</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo e(route('Ba')); ?>" class="nav-link <?php echo e(Request::is('ba') ? 'active' : ''); ?>">
                  <i class="fas fa-minus nav-icon"></i>
                  <p>Berita Acara</p>
                </a>
              </li>

              
              
            </ul>
          </li>
          <?php endif; ?>
          
          <?php if(Auth::user()->seksi_id == 1): ?>
          <li class="nav-item <?php echo e(Request::is(['kecamatan-kelurahan','seksi-pelayanan','hak','user','penandatangan']) ? 'menu-open' : ''); ?>">
            <a href="#" class="nav-link <?php echo e(Request::is(['kecamatan-kelurahan','seksi-pelayanan','hak','user','penandatangan']) ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-database"></i>
              <p>
                Data
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">

              <li class="nav-item">
                <a href="<?php echo e(route('kecamatanKelurahan')); ?>" class="nav-link <?php echo e(Request::is('kecamatan-kelurahan') ? 'active' : ''); ?>">
                  <i class="fas fa-minus nav-icon"></i>
                  <p>Kecamatan & Kelurahan</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo e(route('seksiPelayanan')); ?>" class="nav-link <?php echo e(Request::is('seksi-pelayanan') ? 'active' : ''); ?>">
                  <i class="fas fa-minus nav-icon"></i>
                  <p>Seksi & Pelayanan</p>
                </a>
              </li>

              

              <li class="nav-item">
                <a href="<?php echo e(route('penandatangan')); ?>" class="nav-link <?php echo e(Request::is('penandatangan') ? 'active' : ''); ?>">
                  <i class="fas fa-minus nav-icon"></i>
                  <p>Penandatangan</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo e(route('user')); ?>" class="nav-link <?php echo e(Request::is('user') ? 'active' : ''); ?>">
                  <i class="fas fa-minus nav-icon"></i>
                  <p>User</p>
                </a>
              </li>

              
            </ul>
          </li>
          <?php endif; ?>

          

          

          
          
          
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside><?php /**PATH D:\programming\Laravel\arsip\resources\views/template/_sidebar.blade.php ENDPATH**/ ?>